#include <stdio.h> 
#include <stdlib.h> 
#include <fcntl.h> 		
#include <unistd.h> 
#include <string.h> 
#include <sys/ioctl.h> 
#include <sys/mman.h> 
///#include <asm/page.h> 
#include "fbutils.h"

static int palette [] =
{
        0x000000, 0xffe080, 0xff0000, 0xe0c0a0, 0x0000FF 
};
#define NR_COLORS (sizeof (palette) / sizeof (palette [0]))

int main() 
{

        int i;
	if (open_framebuffer()) {
                close_framebuffer();
                exit(1);
        }

        for (i = 0; i < NR_COLORS; i++)
                setcolor (i, palette [i]);

        fillrect( 200, 100, 600, 200, 4 );
        rect( 220, 110, 580, 180, 2 );

        put_string_wide_center (xres / 2, yres / 4,
                           "Welcome to CADTC", 1);


        put_string_center (xres / 2, yres / 4 + 40,
                           "Embedded Linux Course", 1);

        printf("xres = %d, yres = %d\n", xres, yres);
          close_framebuffer();

 
        return 0; 
}


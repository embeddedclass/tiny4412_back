#!/bin/sh

if [ $# = 1 ]; then
    case "$1" in
        "clean")
            MAKING=0
            ;;
        "make")
            MAKING=1
            ;;
    esac
fi


if [ $MAKING = 0 ]; then
    make clean
    if [ $? != 0 ]; then
	    exit 1
    fi						
fi
if [ $MAKING = 1 ]; then
    make  
    if [ $? != 0 ]; then
	    exit 1
   fi	

fi

cd ..
